package vivid.musictheory.pitch;
/** pitch is a lookup of all 12 available notes in order
 *  other classes use this as reference data
 * **/
public class Notes{
	public static final String[] values = {"E","F","Fs","G","Gs","A","As","B","C","Cs","D","Ds"};
}