package vivid.musictheory.validator;

public interface Validator{

	public boolean validate(String param);

}