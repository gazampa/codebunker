package parser;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;
import java.util.List;
import java.util.ArrayList;
import java.io.CharArrayWriter;

public class WorkflowParser extends DefaultHandler {

        private boolean inAlerts;
        private boolean inFullName;
		private boolean inCCEmails;
		private boolean inDescription;
        private boolean inRecipients;
        private boolean inRecipient;
		private boolean inTemplate;

        private String fullName;
		private String ccEmails;
		private String description;
        private String recipient;
		private String templateName;

		private CharArrayWriter contents = new CharArrayWriter();
		private Data currentAlert;
		private List<String> aggField;
		private List<Data> result = new ArrayList<Data>();

        @Override
        public void characters(char[] ch, int start, int length) throws SAXException {
			contents.write( ch, start, length );
        }

        @Override
        public void startElement(String uri, String localName,
            String qName, Attributes attributes) throws SAXException {

            contents.reset();

            if (localName != null) {
                if (localName.equals("alerts")) {
					currentAlert = new Data();
					result.add(currentAlert);
					aggField = new ArrayList<String>();
					currentAlert.setAggregateField(aggField);
                    inAlerts = true;
                }
				if (localName.equals("fullName")) {
					inFullName = true;
				}
                if (localName.equals("ccEmails")) {
                    inCCEmails = true;
                }
                if (localName.equals("description")) {
                    inDescription = true;
                }
                if (localName.equals("recipients")) {
                    inRecipients = true;
                }
                if (localName.equals("recipient")) {
                    inRecipient = true;
                }
                if (localName.equals("template")) {
                    inTemplate = true;
                }
            }
        }

        @Override
        public void endElement(String uri, String localName, String qName) throws SAXException {
            if (localName != null) {
                if (localName.equals("alerts")) {
                    inAlerts = false;
                }
                if (inAlerts && localName.equals("fullName")) {
                    inFullName = false;
                    currentAlert.setFieldName(contents.toString());
                }
                if (inAlerts && localName.equals("ccEmails")) {
                    inCCEmails = false;
                    currentAlert.setFieldName2(contents.toString());
                }
                if (localName.equals("description")) {
                    inDescription = false;
                }
                if (localName.equals("recipients")) {
                    inRecipients = false;
                }
                if (inAlerts && inRecipient && localName.equals("recipient")) {
                    inRecipient = false;
                	aggField.add((contents.toString()));
                }
                if (localName.equals("template")) {
                    inTemplate = false;
                }

            }
        }

        @Override
        public void startDocument( ) throws SAXException { }

        @Override
        public void endDocument( ) throws SAXException { }

		public List<Data> getResult(){ return result;}

		public class Data{
			String fieldName;
			String fieldName2;
			String fieldName3;
			List<String> aggregateField;

			Data(){}

			public String getFieldName(){ return fieldName; }
			public String getFieldName2(){ return fieldName2; }
			public String getFieldName3(){ return fieldName3; }
			public List<String> getAggregateField(){ return aggregateField; }

			private void setFieldName(String val){ fieldName=val; }
			private void setFieldName2(String val){ fieldName2=val; }
			private void setFieldName3(String val){ fieldName3=val; }
			private void setAggregateField(List<String> obj){ this.aggregateField = obj; }
			public String toString(){
				StringBuilder result = new StringBuilder();
				result.append(fieldName);
				result.append(" :: ");
				result.append(fieldName2);
				if ( null!=aggregateField ){
					for (String field : aggregateField){
						result.append(" :: ");
						result.append(field);
					}
				}

				return result.toString();

				}

		}

}

        	//if (inAlerts && inFullName ) { fullName = new String(ch, start, length);System.out.print(" alert fullname : ");System.out.println(fullName);}
        	//if (inAlerts && inDescription ) { description = new String(ch, start, length);System.out.print(" ...description : ");System.out.println(description);}
        	//if (inAlerts && inCCEmails ) { ccEmails = new String(ch, start, length);System.out.print(" ...ccEmail : ");System.out.println(ccEmails);}
            //if (inAlerts && inRecipients && inRecipient) { recipient = new String(ch, start, length);System.out.print("...recipient : ");System.out.println(recipient);}
