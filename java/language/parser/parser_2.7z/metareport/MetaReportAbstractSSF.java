package metareport;

import parser.WorkflowParser;
import java.io.OutputStream;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import java.util.List;
import java.io.IOException;

public abstract class MetaReportAbstractSSF implements MetaReportInterface{

	protected Workbook wb;

	public MetaReportAbstractSSF(){this.wb=new HSSFWorkbook();}

	public MetaReportAbstractSSF(Workbook wb){this.wb=wb;}

	public void createReport(String name, WorkflowParser parser){
		Sheet sheet = wb.createSheet(name);
		List<WorkflowParser.Data> contents = parser.getResult();
		for (int j = 0; j < contents.size(); j++){
			WorkflowParser.Data contentLine = contents.get(j);
			Row row = sheet.createRow(j+1);
			String dataLine = contentLine.toString();
			System.out.println(dataLine);
			String[] cellElements = dataLine.split("::");
			if ( null != cellElements ){
				for ( int jj = 0; jj < cellElements.length; jj++){
					Cell cell = row.createCell(jj);
					cell.setCellValue(cellElements[jj]);
				}
			}
		}
	}

	public void saveReport(OutputStream out) throws IOException{
		try{
			wb.write(out);
			out.close();
		}catch(IOException ioe){
			System.out.println("IO Exception Error Saving Report As File" + ioe);
		}
	}

}