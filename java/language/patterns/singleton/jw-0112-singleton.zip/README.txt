The example code shows how two instances of a Singleton class can be instantiated in a servlet engine. The behavior of the code depends on the servlet engine and the classloading policy that you have defined. In iPlanet 4, for example, each servlet gets its own classloader unless you configure the server otherwise.

The example consists of three classes:
ServletA: A servlet that gives information on its own identity and that of the one instance of SingletonX. ServletA also shows that servlet classes are most commonly instantiated only once.
ServletB: Identical code to ServletA. Of course, it is usually a bad idea to copy code; this example does this to demonstrate what happens when two servlets call a Singelton.
SingletonX: A singleton class that shows the most common implementation of the Singleton Design Pattern.

See the comments of a discussion of implementation and suggestions for building further examples.

Compile the code with servlet.jar (available in most IDE's and all servlet engines) in the classpath. Place the compiled files in the servlet engine's classpath. Although you can surf directly to the servlets from a browser, you may want to put singletonServlets.html--which shows the two servlets in convenient frames--in your server's webroot.
